﻿namespace CatShop.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Cat
    {
       // TODO
    }
}
